@interface Utilities : NSObject

+ (NSString*)getApplicationTimestamp;
+ (NSDate*)getApplicationBuildTime;

@end