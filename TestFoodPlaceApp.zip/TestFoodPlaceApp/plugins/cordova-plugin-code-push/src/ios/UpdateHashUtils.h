@interface UpdateHashUtils : NSObject

+ (NSString*)getBinaryHash:(NSError**)error;

@end